package jobSequencing;

import java.util.Arrays;
import java.util.Comparator;

class Job {
    int id, deadline, profit;

    public Job(int id, int deadline, int profit) {
        this.id = id;
        this.deadline = deadline;
        this.profit = profit;
    }
}

public class jobSequencing {

    // Function to find the maximum profit and job sequence
    public static void jobSequence(Job[] jobs, int n) {
        // Sort jobs in decreasing order of profit
        Arrays.sort(jobs, new Comparator<Job>() {
            public int compare(Job j1, Job j2) {
                return j2.profit - j1.profit;
            }
        });

        // Array to keep track of free time slots
        int[] result = new int[n];
        boolean[] slot = new boolean[n];

        // Initialize all slots as free
        Arrays.fill(slot, false);

        int totalProfit = 0;
        int countJobs = 0;

        // Iterate through all the jobs
        for (int i = 0; i < n; i++) {
            // Find a free slot for this job (starting from the latest possible time)
            for (int j = Math.min(n, jobs[i].deadline) - 1; j >= 0; j--) {
                // If slot is free
                if (!slot[j]) {
                    slot[j] = true;
                    result[j] = jobs[i].id;
                    totalProfit += jobs[i].profit;
                    countJobs++;
                    break;
                }
            }
        }

        // Print the job sequence and total profit
        System.out.println("Total number of jobs selected: " + countJobs);
        System.out.println("Total profit: " + totalProfit);
        System.out.println("Jobs selected:");

        for (int i = 0; i < n; i++) {
            if (slot[i]) {
                System.out.print(result[i] + " ");
            }
        }
    }

    public static void main(String[] args) {
        // Sample jobs
        Job[] jobs = {
            new Job(1, 4, 20),
            new Job(2, 1, 10),
            new Job(3, 1, 40),
            new Job(4, 1, 30)
        };

        int n = jobs.length;
        jobSequence(jobs, n);
    }
}
