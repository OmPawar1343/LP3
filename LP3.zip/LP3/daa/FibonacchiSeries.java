package fibonacci;

public class FibonacchiSeries {

    // Method to calculate Fibonacci number and count the steps
    public static int[] calculateFibonacci(int n) {
        // Array to store Fibonacci number and step count
        int[] result = new int[2];
        
        if (n <= 1) {
            result[0] = n;  // Fibonacci number
            result[1] = 1;  // Number of steps
            return result;
        }

        int a = 0, b = 1, c = 0;
        int steps = 1;  // Initial step count

        for (int i = 2; i <= n; i++) {
            c = a + b;
            a = b;
            b = c;
            steps++;  // Increment the step count for each iteration
        }

        result[0] = c;   // Store the Fibonacci number
        result[1] = steps; // Store the number of steps
        return result;
    }

    public static void main(String[] args) {
        int n = 10;  // Fibonacci number index
        int[] result = calculateFibonacci(n);
        
        System.out.println("Fibonacci number at index " + n + " is: " + result[0]);
        System.out.println("Total steps taken: " + result[1]);
    }
}
